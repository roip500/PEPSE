package pepse.world;

public class Avatar {
}
