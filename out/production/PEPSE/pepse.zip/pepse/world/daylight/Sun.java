package pepse.world.daylight;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.components.CoordinateSpace;
import danogl.components.Transition;
import danogl.gui.rendering.OvalRenderable;
import danogl.util.Vector2;

import java.awt.*;

public class Sun{

    /**
     * creates the sun object and adds it to gameObjectCollection
     * @param gameObjectCollection list of all the game objects.
     * @param windowDimension size of the window
     * @param sunLayer layer in the board
     * @return game object that represents the sun
     */
    public static GameObject create(GameObjectCollection gameObjectCollection,
                                    Vector2 windowDimension,
                                    int sunLayer,
                                    float cycleLength){

        GameObject sun = new GameObject(Vector2.ZERO, windowDimension,
                new OvalRenderable(Color.YELLOW));
        sun.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        sun.setTag("sun");
        new Transition<Float>(sun,
                aFloat -> sun.setCenter(sun.getCenter().add(new Vector2(10, 10))),
                -90F,
                90F,
                Transition.LINEAR_INTERPOLATOR_FLOAT,
                cycleLength,
                Transition.TransitionType.TRANSITION_LOOP,
                null);
        gameObjectCollection.addGameObject(sun, sunLayer);
        return sun;
    }
//
//    Math.abs((float) Math.cos(aFloat)) * Vector2.UP.x(),
//            Math.abs((float) Math.sin(aFloat)) * Vector2.UP.x())

}


